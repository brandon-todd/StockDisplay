const data = 
[
 {
    name: "Ford Motor Company",
    change: "+0.38",
    date: "Mon Nov 15 13:31:10 2021"

 },
 {
    name: "Lucid Group Inc",
    change: "+0.74",
    date: "Mon Nov 15 13:31:10 2021"

 },
 {
    name: "Tilray Inc",
    change: "+0.23",
    date: "Mon Nov 15 13:31:10 2021"

 },
 {
    name: "Advanced Micro Devices Inc",
    change: "-1.26",
    date: "Mon Nov 15 13:31:10 2021"

 },
 {
    name: "NIO Inc",
    change: "-1.86",
    date: "Mon Nov 15 13:31:10 2021"

 },
 {
    name: "Apple Inc",
    change: "+0.17",
    date: "Mon Nov 15 13:31:10 2021"

 },
 {
    name: "AMC Entertainment Holdings Inc",
    change: "+2.73",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "NVIDIA Corporation",
    change: "-4.38",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "AT&T Inc",
    change: "-0.20",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "Tesla Inc",
    change: "-17.11",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "Palantir Technologies Inc",
    change: "+0.55",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "FuelCell Energy Inc",
    change: "-0.47",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "Paysafe Limited",
    change: "-0.0583",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "Oatly Group AB",
    change: "-2.61",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "Bank of America Corporation",
    change: "+0.22",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "Marathon Digital Holdings Inc",
    change: "-17.18",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "SoFi Technologies Inc",
    change: "+0.30",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "Riot Blockchain Inc",
    change: "-1.15",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "New Oriental Education & Technology Group Inc",
    change: "-0.0800",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "QuantumScape Corporation",
    change: "+2.19",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "Roblox Corporation",
    change: "+0.18",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "Meta Platforms Inc",
    change: "+7.85",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "Clover Health Investments Corp",
    change: "+0.45",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "Snap Inc",
    change: "+2.13",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "EVgo Inc",
    change: "-2.67",
    date: "Mon Nov 15 13:31:11 2021"

 },
 {
    name: "Ford Motor Company",
    change: "+0.38",
    date: "Mon Nov 15 13:38:05 2021"

 },
 {
    name: "Lucid Group Inc",
    change: "+0.41",
    date: "Mon Nov 15 13:38:05 2021"

 },
 {
    name: "Tilray Inc",
    change: "+0.29",
    date: "Mon Nov 15 13:38:05 2021"

 },
 {
    name: "Advanced Micro Devices Inc",
    change: "-1.05",
    date: "Mon Nov 15 13:38:05 2021"

 },
 {
    name: "NIO Inc",
    change: "-1.92",
    date: "Mon Nov 15 13:38:05 2021"

 },
 {
    name: "Apple Inc",
    change: "+0.02",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "AMC Entertainment Holdings Inc",
    change: "+2.70",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "NVIDIA Corporation",
    change: "-4.02",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "AT&T Inc",
    change: "-0.14",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "Tesla Inc",
    change: "-23.28",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "Palantir Technologies Inc",
    change: "+0.51",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "FuelCell Energy Inc",
    change: "-0.48",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "Marathon Digital Holdings Inc",
    change: "-17.79",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "Paysafe Limited",
    change: "-0.0350",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "Oatly Group AB",
    change: "-2.59",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "Bank of America Corporation",
    change: "+0.24",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "SoFi Technologies Inc",
    change: "+0.16",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "Riot Blockchain Inc",
    change: "-1.12",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "New Oriental Education & Technology Group Inc",
    change: "-0.0802",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "Roblox Corporation",
    change: "+1.00",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "QuantumScape Corporation",
    change: "+1.86",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "Meta Platforms Inc",
    change: "+7.53",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "Clover Health Investments Corp",
    change: "+0.46",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "Snap Inc",
    change: "+2.09",
    date: "Mon Nov 15 13:38:06 2021"

 },
 {
    name: "EVgo Inc",
    change: "-2.74",
    date: "Mon Nov 15 13:38:06 2021"
 }
]
